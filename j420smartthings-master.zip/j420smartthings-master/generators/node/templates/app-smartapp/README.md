# <%= name %> README

This is the README for your SmartThings Automation "<%= name %>". After writing a brief description, we recommend including the following sections.

## Features

Describe specific features of your app.

## Known Issues

Calling out known issues can help limit users opening duplicate issues against your app.

## Release Notes

Users appreciate release notes as you update your app.
